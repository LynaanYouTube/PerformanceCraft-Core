PerformanceCraft Core V1
Minecraft 26.3 / Fabric

Purpose:
A conservative performance foundation for PerformanceCraft.

Design rules:
- Preserve the current 80+ FPS shader baseline.
- Prefer frame-time consistency over peak FPS.
- Do not change the established visual style in V1.
- Keep terrain, entity, hand/item, armor/glint, water and shadow paths intact.
- Defer expensive visual effects until the baseline is measured.

V1 is a configuration/architecture foundation rather than an aggressive
shader rewrite. This is intentional: the current Complementary-based shader
is already performing well, and changing several rendering systems at once
would make regressions difficult to identify.

Next measurement targets:
1. Overworld
2. Cave
3. Nether
4. Rain
5. Entity-heavy area
6. PvP stress test

Rollback:
Use the original PerformanceCraft Complementary Performance ZIP.
